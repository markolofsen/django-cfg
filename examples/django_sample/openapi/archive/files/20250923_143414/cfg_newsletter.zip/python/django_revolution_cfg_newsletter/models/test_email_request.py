from collections.abc import Mapping
from typing import Any, TypeVar, Optional, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field
import json
from .. import types

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import Union


T = TypeVar("T", bound="TestEmailRequest")


@_attrs_define
class TestEmailRequest:
    """Simple serializer for test email.

    Attributes:
        email (str):
        subject (Union[Unset, str]):  Default: 'Django CFG Newsletter Test'.
        message (Union[Unset, str]):  Default: 'This is a test email from Django CFG Newsletter.'.
    """

    email: str
    subject: Union[Unset, str] = "Django CFG Newsletter Test"
    message: Union[Unset, str] = "This is a test email from Django CFG Newsletter."
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        email = self.email

        subject = self.subject

        message = self.message

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "email": email,
            }
        )
        if subject is not UNSET:
            field_dict["subject"] = subject
        if message is not UNSET:
            field_dict["message"] = message

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("email", (None, str(self.email).encode(), "text/plain")))

        if not isinstance(self.subject, Unset):
            files.append(("subject", (None, str(self.subject).encode(), "text/plain")))

        if not isinstance(self.message, Unset):
            files.append(("message", (None, str(self.message).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        email = d.pop("email")

        subject = d.pop("subject", UNSET)

        message = d.pop("message", UNSET)

        test_email_request = cls(
            email=email,
            subject=subject,
            message=message,
        )

        test_email_request.additional_properties = d
        return test_email_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
