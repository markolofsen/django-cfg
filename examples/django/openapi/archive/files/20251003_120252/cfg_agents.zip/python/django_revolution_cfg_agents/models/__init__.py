"""Contains all the data models used in inputs/outputs"""
