"""
Django Config Configuration

Core configuration models and settings.
"""

from pydantic import Field
from pydantic_settings import BaseSettings


class DjangoConfigSettings(BaseSettings):
    """Core Django Config settings."""
    
    version: str = Field("1.0.1", description="Package version")
    debug: bool = Field(False, description="Debug mode")
    environment: str = Field("production", description="Environment (development/staging/production)")
    
    class Config:
        env_prefix = "DJANGO_CFG_"
